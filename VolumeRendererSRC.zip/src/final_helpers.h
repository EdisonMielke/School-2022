/*
*
*
*
Here are a crap tonne of helper functions dedicated to keeping main neat, these will be lightly commented
as hopefully the variable/function names will be self explanitory
*
*
*
*/

void
vectorNormalize(double a[3], double d[3])
{
    double b[3];
    b[0] = a[0] * a[0];
    b[1] = a[1] * a[1];
    b[2] = a[2] * a[2];
    double c = sqrt(b[0] + b[1] + b[2]);
    d[0] = a[0] / c;
    d[1] = a[1] / c;
    d[2] = a[2] / c;
}

void
dotMultiplication(double a[3], double b[3], double c[3])
{
    c[0] = ((a[1] * b[2]) - (a[2] * b[1]));
    c[1] = ((a[2] * b[0]) - (a[0] * b[2]));
    c[2] = ((a[0] * b[1]) - (a[1] * b[0]));
}

void
vectorAddition(double a[3], double b[3], double c[3])
{
    c[0] = (a[0] + b[0]);
    c[1] = (a[1] + b[1]);
    c[2] = (a[2] + b[2]);
}

void
vectorSubtraction(double a[3], double b[3], double c[3])
/*
* I realize this is kind of unnecessary because I can just add with a negative
* but I think it's neater in main
*/
{
    c[0] = (a[0] - b[0]);
    c[1] = (a[1] - b[1]);
    c[2] = (a[2] - b[2]);
}

void
uvFillout(double a[3], double b[3], double c[3])
/*
* This fills out the r_u and r_v arrays in main
*/
{
    c[0] = ((a[1] * b[2]) - (a[2] * b[1]));
    c[1] = ((a[2] * b[0]) - (a[0] * b[2]));
    c[2] = ((a[0] * b[1]) - (a[1] * b[0]));
    double mag = sqrt((c[0] * c[0]) + (c[1] * c[1]) + (c[2] * c[2]));
    c[0] = (c[0] / mag);
    c[1] = (c[1] / mag);
    c[2] = (c[2] / mag);
}

void
xyFillout(double a[3], double b[3], int angle, int length)
/*
* This fills out the r_x and r_y arrays in main
*/
{
    double rads = (angle * (3.1415926535897932384626 / 180));
    double newAngle = rads / 2;
    double tanAngle = tan(newAngle);
    double scalar = (2 * tanAngle / length);
    b[0] = a[0] * scalar;
    b[1] = a[1] * scalar;
    b[2] = a[2] * scalar;
}

void
directionFillout(double look[3], double x[3], double y[3], int i, int j, int width, int height, double direction[3])
/*
* This fills out the distance array in main
*/
{
    double mag = sqrt((look[0] * look[0]) + (look[1] * look[1]) + (look[2] * look[2]));
    double xScal = (((2.0 * i) + 1.0 - width) / 2.0);
    double yScal = (((2.0 * j) + 1.0 - height) / 2.0);
    direction[0] = ((look[0] / mag) + (x[0] * xScal) + (y[0] * yScal));
    direction[1] = ((look[1] / mag) + (x[1] * xScal) + (y[1] * yScal));
    direction[2] = ((look[2] / mag) + (x[2] * xScal) + (y[2] * yScal));
}

double
correctOpacity(double opacity, int sampleCount)
{
    return 1.0 - pow(((1.0 - opacity)), 500.0 / sampleCount);
}

void
mixRGB(double RGBF[3], double RGBB[3], double RGBM[3], double opacityF, double opacityB)
{
    RGBM[0] = (opacityF * RGBF[0]) + (((1.0 - opacityF) * opacityB) * RGBB[0]);
    RGBM[1] = (opacityF * RGBF[1]) + (((1.0 - opacityF) * opacityB) * RGBB[1]);
    RGBM[2] = (opacityF * RGBF[2]) + (((1.0 - opacityF) * opacityB) * RGBB[2]);
}

double
mixOpacity(double opacityF, double opacityB)
{
    return opacityF + (1.0 - opacityF) * opacityB;
}

void
assignToDouble(double doubleRGB[3], unsigned char charRGB[3])
{
    doubleRGB[0] = (double)charRGB[0] / 255.0;
    doubleRGB[1] = (double)charRGB[1] / 255.0;
    doubleRGB[2] = (double)charRGB[2] / 255.0;
}

void
assignToFinal(double finalArray[3], double RGB[3], double opacity)
{
    finalArray[0] = RGB[0];
    finalArray[1] = RGB[1];
    finalArray[2] = RGB[2];
    finalArray[3] = opacity;
}
void
assignToChar(unsigned char charRGB[3], double doubleRGB[4])
{
    charRGB[0] = doubleRGB[0] * 255.0; //* doubleRGB[3]
    charRGB[1] = doubleRGB[1] * 255.0; //* doubleRGB[3]
    charRGB[2] = doubleRGB[2] * 255.0; //* doubleRGB[3]
}
void
assignToIMG(unsigned char charRGB[3], unsigned char* buffer, vtkImageData* IMG, int i, int j)
{
    buffer = (unsigned char*)IMG->GetScalarPointer(i, j, 0);
    buffer[0] = charRGB[0];
    buffer[1] = charRGB[1];
    buffer[2] = charRGB[2];
}