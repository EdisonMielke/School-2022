#include <math.h>
#include <vtkPNGWriter.h>
#include "vtkCamera.h"
#include "vtkImageData.h"
#include <vtkRectilinearGrid.h>
#include <vtkPolyData.h>
#include <vtkPointData.h>
#include <vtkDataSetReader.h>
#include "final_helpers.h"

/*
*
CHANGE FILENAME TO WHATEVER IS APPROPRIATE
*
*/

char* FILENAME = "astro512.vtk";

/*
*
CHAMGE SAMPLES TO DESIRED RESOLUTION
*
*/

const int SAMPLES = 1024;

/*
*
CHANGE HEIGHT AND WIDTH TO DESIRED RESOLUTION
*
*/
int HEIGHT = 1000, WIDTH = 1000;


struct Camera
{
    double          near, far;
    double          angle;
    double          position[3];
    double          focus[3];
    double          up[3];
};

struct TransferFunction
{
    double          min;
    double          max;
    int             numBins;
    unsigned char  *colors;  // size is 3*numBins
    double         *opacities; // size is numBins

    // Take in a value and applies the transfer function.
    // Step #1: figure out which bin "value" lies in.
    // If "min" is 2 and "max" is 4, and there are 10 bins, then
    //   bin 0 = 2->2.2
    //   bin 1 = 2.2->2.4
    //   bin 2 = 2.4->2.6
    //   bin 3 = 2.6->2.8
    //   bin 4 = 2.8->3.0
    //   bin 5 = 3.0->3.2
    //   bin 6 = 3.2->3.4
    //   bin 7 = 3.4->3.6
    //   bin 8 = 3.6->3.8
    //   bin 9 = 3.8->4.0
    // and, for example, a "value" of 3.15 would return the color in bin 5
    // and the opacity at "opacities[5]".

    int GetBin(double value)
    {
        return numBins * (value - min) / (max - min);
    }

    void ApplyTransferFunction(double value, unsigned char *RGB, double &opacity)
    {
        if (value > max || value < min) 
        {
            //cerr << "Out of Range: no valid bin\n";
            RGB[0] = 0;
            RGB[1] = 0;
            RGB[2] = 0;
            opacity = 0;
        }
        else
        {
            int bin = GetBin(value);
            //cout << "Mapped to Bin " << bin << "\n";
            RGB[0] = colors[3 * bin + 0];
            RGB[1] = colors[3 * bin + 1];
            RGB[2] = colors[3 * bin + 2];
            opacity = opacities[bin];
        }
    }
};

TransferFunction
SetupTransferFunction(void)
{
    int  i;

    TransferFunction rv;
    rv.min = 10;
    rv.max = 15;
    rv.numBins = 256;
    rv.colors = new unsigned char[3*256];
    rv.opacities = new double[256];
    unsigned char charOpacity[256] = {
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 1, 1, 1, 2, 2, 3, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 13, 14, 14, 14, 14, 
            14, 14, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 5, 4, 3, 2, 3, 3, 4, 5, 6, 7, 8, 9, 10, 11, 
            12, 13, 14, 15, 16, 17, 17, 17, 17, 17, 17, 17, 16, 16, 15, 14, 13, 12, 11, 9, 8, 7, 
            6, 5, 5, 4, 3, 3, 3, 4, 5, 6, 7, 8, 9, 11, 12, 14, 16, 18, 20, 22, 24, 27, 29, 32, 35, 
            38, 41, 44, 47, 50, 52, 55, 58, 60, 62, 64, 66, 67, 68, 69, 70, 70, 70, 69, 68, 67, 
            66, 64, 62, 60, 58, 55, 52, 50, 47, 44, 41, 38, 35, 32, 29, 27, 24, 22, 20, 20, 23, 
            28, 33, 38, 45, 51, 59, 67, 76, 85, 95, 105, 116, 127, 138, 149, 160, 170, 180, 189, 
            198, 205, 212, 217, 221, 223, 224, 224, 222, 219, 214, 208, 201, 193, 184, 174, 164, 
            153, 142, 131, 120, 109, 99, 89, 79, 70, 62, 54, 47, 40, 35, 30, 25, 21, 17, 14, 12, 
            10, 8, 6, 5, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0
        };

    for (i = 0 ; i < 256 ; i++)
        rv.opacities[i] = charOpacity[i]/255.0;
    const int numControlPoints = 8;
    unsigned char controlPointColors[numControlPoints*3] = { 
           71, 71, 219, 0, 0, 91, 0, 255, 255, 0, 127, 0, 
           255, 255, 0, 255, 96, 0, 107, 0, 0, 224, 76, 76 
       };
    double controlPointPositions[numControlPoints] = { 0, 0.143, 0.285, 0.429, 0.571, 0.714, 0.857, 1.0 };
    for (i = 0 ; i < numControlPoints-1 ; i++)
    {
        int start = controlPointPositions[i]*rv.numBins;
        int end   = controlPointPositions[i+1]*rv.numBins+1;
        //cerr << "Working on " << i << "/" << i+1 << ", with range " << start << "/" << end << endl;
        if (end >= rv.numBins)
            end = rv.numBins-1;
        for (int j = start ; j <= end ; j++)
        {
            double proportion = (j/(rv.numBins-1.0)-controlPointPositions[i])/(controlPointPositions[i+1]-controlPointPositions[i]);
            if (proportion < 0 || proportion > 1.)
                continue;
            for (int k = 0 ; k < 3 ; k++)
                rv.colors[3*j+k] = proportion*(controlPointColors[3*(i+1)+k]-controlPointColors[3*i+k])
                                 + controlPointColors[3*i+k];
        }
    }    

    return rv;
}

Camera
SetupCamera(void)
{
    Camera rv;
    rv.focus[0] = 0;
    rv.focus[1] = 0;
    rv.focus[2] = 0;
    rv.up[0] = 0;
    rv.up[1] = -1;
    rv.up[2] = 0;
    rv.angle = 30;
    rv.near = 7.5e+7;
    rv.far = 1.4e+8;
    rv.position[0] = -8.25e+7;
    rv.position[1] = -3.45e+7;
    rv.position[2] = 3.35e+7;

    return rv;
}

void
WriteImage(vtkImageData* img, const char* filename)
/*
* Shamelessly ripped from Project 3
*/
{
    std::string full_filename = filename;
    full_filename += ".png";
    vtkPNGWriter* writer = vtkPNGWriter::New();
    writer->SetInputData(img);
    writer->SetFileName(full_filename.c_str());
    writer->Write();
    writer->Delete();
}

vtkImageData*
NewImage(int width, int height)
/*
* Shamelessly ripped from Project 3
*/
{
    vtkImageData* image = vtkImageData::New();
    image->SetDimensions(width, height, 1);
    //image->SetWholeExtent(0, width-1, 0, height-1, 0, 0);
    //image->SetUpdateExtent(0, width-1, 0, height-1, 0, 0);
    //image->SetNumberOfScalarComponents(3);
    image->AllocateScalars(VTK_UNSIGNED_CHAR, 3);
    //image->AllocateScalars();

    return image;
}

int 
GetPointIndex(const int* idx, const int* dims)
/*
* Helper function to get the point index of a particular idx
* Shamelessly ripped from Project 3
*/
{
    return idx[2] * dims[0] * dims[1] + idx[1] * dims[0] + idx[0];
}

double
EvaluateFieldAtLocation(const double* pt, const int* dims,
    const float* X, const float* Y, const float* Z, const float* F)
{

    //initialize indexes and positions relative to point
    
    
    int leftXPos = 0, downYPos = 0, frontZPos = 0;
    double leftX = 0, rightX = 0, upY = 0, downY = 0, frontZ = 0, backZ = 0;

    //use the loop to find the indexes
    for (int i = 0; i < dims[0] - 1; i++)
    {
        if (X[i] < pt[0])
            leftXPos = i;
        if (Y[i] < pt[1])
            downYPos = i;
        if (Z[i] < pt[2])
            frontZPos = i;
    }

    //Yeah, largely unnecessary but I like the readability
    int rightXPos = leftXPos + 1;
    int upYPos = downYPos + 1;
    int backZPos = frontZPos + 1;

    //dunno if I actually need these values but it helps to visualize
    leftX = X[leftXPos];
    rightX = X[rightXPos];
    downY = Y[downYPos];
    upY = Y[upYPos];
    frontZ = Z[frontZPos];
    backZ = Z[backZPos];

    //Create the corners
    int frontBotLeftidx[3] = { leftXPos,   downYPos,   frontZPos };//V000
    int frontBotRightidx[3]= { leftXPos+1, downYPos,   frontZPos }; //V100
    int backBotLeftidx[3]  = { leftXPos,   downYPos+1, frontZPos }; //V010
    int backBotRightidx[3] = { leftXPos+1, downYPos+1, frontZPos }; //V110
    int frontTopLeftidx[3] = { leftXPos,   downYPos,   frontZPos+1 }; //V001
    int frontTopRightidx[3]= { leftXPos+1, downYPos,   frontZPos+1 }; //V101
    int backTopLeftidx[3]  = { leftXPos,   downYPos+1, frontZPos+1 }; //V011
    int backTopRightidx[3] = { leftXPos+1, downYPos+1, frontZPos+1 }; //V111

    //find the point index of the corners
    int frontBotLeftPos  = GetPointIndex(frontBotLeftidx, dims);
    int frontBotRightPos = GetPointIndex(frontBotRightidx, dims);
    int backBotLeftPos   = GetPointIndex(backBotLeftidx, dims);
    int backBotRightPos  = GetPointIndex(backBotRightidx, dims);
    int frontTopLeftPos  = GetPointIndex(frontTopLeftidx, dims);
    int frontTopRightPos = GetPointIndex(frontTopRightidx, dims);
    int backTopLeftPos   = GetPointIndex(backTopLeftidx, dims);
    int backTopRightPos  = GetPointIndex(backTopRightidx, dims);

    //Do alternative interpolation technique (Thanks Nik for the idea, it was WAY neater than just interpolating 
    //7 times with the whole interpolation process

    double xd = (pt[0] - X[leftXPos]) / (X[rightXPos] - X[leftXPos]);
    double yd = (pt[1] - Y[downYPos]) / (Y[upYPos] - Y[downYPos]);
    double zd = (pt[2] - Z[frontZPos]) / (Z[backZPos] - Z[frontZPos]);

    double frontBotMid = F[frontBotLeftPos] * (1.0 - xd) + F[frontBotRightPos] * (xd); //000 //100
    double frontTopMid = F[frontTopLeftPos] * (1.0 - xd) + F[frontTopRightPos] * (xd); //001 //101
    double backBotMid  = F[backBotLeftPos]  * (1.0 - xd) + F[backBotRightPos] * (xd); //010 //110
    double backTopMid  = F[backTopLeftPos]  * (1.0 - xd) + F[backTopRightPos] * (xd); //011 //111

    double botMid      = frontBotMid * (1.0 - yd) + backBotMid * (yd);
    double topMid      = frontTopMid * (1.0 - yd) + backTopMid * (yd); 

    double finalMid = botMid * (1.0 - zd) + topMid * (zd);

    return finalMid;
    
}

int main()
{
    TransferFunction tf = SetupTransferFunction();
    Camera rv = SetupCamera();

    double r_u[3], r_v[3], r_x[3], r_y[3], look[3], direction50[3], direction[3], sample[3], finalPixels[4];
    int stepSize = 0, npercent = 1;
    unsigned char finalRGB[3];

    //Step 1 setup
    vectorSubtraction(rv.focus, rv.position, look);
    uvFillout(look, rv.up, r_u);
    uvFillout(look, r_u, r_v);
    xyFillout(r_u, r_x, rv.angle, WIDTH);
    xyFillout(r_v, r_y, rv.angle, HEIGHT);
    stepSize = round((rv.far - rv.near) / (SAMPLES - 1));
    directionFillout(look, r_x, r_y, 50, 50, WIDTH, HEIGHT, direction50);
    
    //Step 1 prints
    cout << "R_u =" << r_u[0] << ", " << r_u[1] << ", " << r_u[2] << "\n";
    cout << "R_v =" << r_v[0] << ", " << r_v[1] << ", " << r_v[2] << "\n";
    cout << "R_x =" << r_x[0] << ", " << r_x[1] << ", " << r_x[2] << "\n";
    cout << "R_y =" << r_y[0] << ", " << r_y[1] << ", " << r_y[2] << "\n";
    cout << "Ray origin = " << rv.position[0] << ", " << rv.position[1] << ", " << rv.position[2] << "\n";
    cout << "Ray direction at 50,50 = " << direction50[0] << ", " << direction50[1] << ", " << direction50[2] << "\n";
    cout << "Step size is " << stepSize << "\n";

    //start up VTK
    vtkDataSetReader* rdr = vtkDataSetReader::New();
    rdr->SetFileName(FILENAME);
    rdr->Update();
    //VTK failsafe if input file is not found
    if (rdr->GetOutput() == NULL || rdr->GetOutput()->GetNumberOfCells() == 0)
    {
        cerr << "Could not find input file." << endl;
        exit(EXIT_FAILURE);
    }
    //Create rectilinear Grid
    vtkRectilinearGrid* rgrid = (vtkRectilinearGrid*)rdr->GetOutput();
    int dims[3];
    rgrid->GetDimensions(dims);
    //Get coordinates for each
    float* X = (float *)rgrid->GetXCoordinates()->GetVoidPointer(0);
    float* Y = (float *)rgrid->GetYCoordinates()->GetVoidPointer(0);
    float* Z = (float *)rgrid->GetZCoordinates()->GetVoidPointer(0);
    float* F = (float *)rgrid->GetPointData()->GetScalars()->GetVoidPointer(0);
    //create image and buffer
    vtkImageData* image = nullptr;
    unsigned char* buffer = nullptr;
    image = NewImage(WIDTH, HEIGHT);
    image->SetOrigin(0.0, 0.0, 0.0);
    image->SetSpacing(1.0, 1.0, 1.0);


    //unsigned char finalRGB[3];
    for (int j = 0; j < WIDTH; j++)
    {
        for (int k = 0; k < HEIGHT; k++)
        {

            //STEP2
            /*
            *Locate direction
            *Find value for direction
            *Store value in pointer array
            */
            directionFillout(look, r_x, r_y, j, k, WIDTH, HEIGHT, direction);
            double* values = new double[SAMPLES];
            for (int i = 0; i < SAMPLES; i++)
            {
                sample[0] = rv.position[0] + direction[0] * (rv.near + i * stepSize);
                sample[1] = rv.position[1] + direction[1] * (rv.near + i * stepSize);
                sample[2] = rv.position[2] + direction[2] * (rv.near + i * stepSize);
                double value = EvaluateFieldAtLocation(sample, dims, X, Y, Z, F);
                values[i] = value;
            }

            //STEP3
            //Generate Color information for Sample[0]
            double opacityF, opacityB, opacityM = 0, correctedOpacityF = 0, correctedOpacityB = 0, RGBM[3], RGBBM[3];
            unsigned char RGBF[3], RGBB[3];
            
       
            /*
            *Find next Sample
            *Convert newfound sample to double and convert to percentages
            *Correct Opacity of Back Sample
            */
            tf.ApplyTransferFunction(values[0], RGBF, opacityF);
            assignToDouble(RGBM, RGBF);
            opacityM = correctOpacity(opacityF, SAMPLES);

            //Generate color information for Sample[n]
            for (int i = 1; i < SAMPLES; i++)
            {
                //Find next Sample
                //Convert newfound sample to double and convert to percentages
                //Correct Opacity of Back Sample
                tf.ApplyTransferFunction(values[i], RGBB, opacityB);
                assignToDouble(RGBBM, RGBB);       
                correctedOpacityB = correctOpacity(opacityB, SAMPLES);

                //Transparency step
                RGBM[0] = (RGBM[0]) + (((1.0 - opacityM) * correctedOpacityB) * RGBBM[0]);
                RGBM[1] = (RGBM[1]) + (((1.0 - opacityM) * correctedOpacityB) * RGBBM[1]);
                RGBM[2] = (RGBM[2]) + (((1.0 - opacityM) * correctedOpacityB) * RGBBM[2]);
                opacityM = mixOpacity(opacityM, correctedOpacityB);

                //Assign the composted sample to a double array
                assignToFinal(finalPixels, RGBM, opacityM);
            }
            
            //STEP 4
            //cout << "Red: " << finalPixels[0] << " Green: " << finalPixels[1] << " Blue: " << finalPixels[2] << " Alpha: " << finalPixels[3] << "\n";
            //Assign the double array to a char array
            //Assign the char array to the image for that particular pixel (j, k)
            //cleanup values pointer array
            assignToChar(finalRGB, finalPixels);
            assignToIMG(finalRGB, buffer, image, j, k);
            delete values;
            //cout << "(" << j << "," << k << ") " << "Final color for pixel is " << (int)finalRGB[0] << ", " << (int)finalRGB[1] << ", " << (int)finalRGB[2] << "\n";
        }
        
        //Loading bar I made for funsies
        if ((j % (WIDTH / 100)) == 0)
        {
            cout << "[";
            for (int i = 0; i < npercent/2 ; i++)
            {
                cout << "|";
            }
            for (int i = 0; i < 50-npercent/2; i++)
            {
                cout << " ";
            }
            cout << "] " << npercent << "% Done\r";
            npercent++;
        }
    }
    /*
    * Produce that bad boy of an image!
    */
    WriteImage(image, "Output");
}

